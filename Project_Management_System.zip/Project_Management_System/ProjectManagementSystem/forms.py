from importlib import import_module
from django.conf import settings
from django.contrib.sessions.backends.db import SessionStore
from django import forms
from ProjectManagementSystem.models import User, Client,Project, Milestones, Task, AssignedProject, Notes,SubTask

class UserForm(forms.ModelForm):

    ConfirmPassword = forms.CharField(widget=forms.PasswordInput(attrs={'class':'form-control'}))
    class Meta:
        model= User
        fields= ['Role','FirstName','LastName','UserImage','Email','Password','ConfirmPassword','PhoneNumber','SecurityQuestion','SecurityAnswer','ManagerID','TeamID']

        widgets = {
            'Role': forms.Select(attrs={'class': 'form-control'}),
            'FirstName': forms.TextInput(attrs={'class': 'form-control'}),
            'LastName': forms.TextInput(attrs={'class': 'form-control'}),
            'Email': forms.EmailInput(attrs={'class': 'form-control'}),
            'Password': forms.PasswordInput(attrs={'class': 'form-control'}),
            'PhoneNumber': forms.NumberInput(attrs={'class': 'form-control'}),
            'SecurityQuestion': forms.Select(attrs={'class': 'form-control'}),
            'SecurityAnswer': forms.TextInput(attrs={'class': 'form-control'}),
            'ManagerID': forms.Select(attrs={'class': 'form-control'}),
            'TeamID': forms.Select(attrs={'class': 'form-control'}),
        }

        labels = {
            'FirstName':'First Name:',
            'LastName':'Last Name:',
            'ConfirmPassword': 'Confirm Password:',
            'PhoneNumber':'Phone Number:',
            'SecurityQuestion':'Security Question:',
            'SecurityAnswer':"Security Answer",
            'ManagerID':"Manager:",
            "TeamID":"Team",
            "UserImage": "Image"
                  }

    def clean_ConfirmPassword(self):
        Password = self.cleaned_data["Password"]
        ConfirmPassword = self.cleaned_data["ConfirmPassword"]

        if Password != ConfirmPassword:
            raise forms.ValidationError("password and confirm password do not match")

    def __init__(self,*args,**kwargs):
        super(UserForm,self).__init__(*args, **kwargs)
        self.fields["ManagerID"].queryset = User.objects.filter(Role__RoleID=2)

class ClientForm(forms.ModelForm):
    class Meta:
        model = Client
        fields = '__all__'

        widgets = {
            'ClientName': forms.TextInput(attrs={'class': 'form-control'}),
            'ClientCompanyName': forms.TextInput(attrs={'class': 'form-control'}),
            'ClientEmail': forms.EmailInput(attrs={'class': 'form-control'}),
            'ClientPhoneNumber': forms.NumberInput(attrs={'class': 'form-control'}),
        }

        labels = {
            'ClientName': 'Client Name:',
            'ClientPhoneNumber': 'Phone Number:',
            'ClientEmail':'Email',
            'ClientCompanyName':'Company',
        }

class ProjectForm(forms.ModelForm):

    class Meta:
        model= Project
        fields='__all__'

        widgets={
            'ProjectClientCompanyName':forms.Select(attrs={'class':'form-control'}),
            'ProjectClientName':forms.Select(attrs={'class':'form-control'}),
            'ProjectName': forms.TextInput(attrs={'class': 'form-control'}),
            'ProjectManagerID':forms.Select(attrs={'class':'form-control'}),
            'ProjectStartDate': forms.SelectDateWidget(),
            'ProjectEndDate':forms.SelectDateWidget(),
            'ProjectStatus':forms.Select(attrs={'class':'form-control'})
        }

        labels={
            'ProjectClientCompanyName':'Company',
            'ProjectClientName': 'Client',
            'ProjectName': 'Project Name',
            'ProjectManagerID': 'Manager',
            'ProjectStartDate': 'Start Date',
            'ProjectEndDate': 'End Date',
            'ProjectStatus': 'Project Status',
        }

    def __init__(self, *args, **kwargs):
        super(ProjectForm, self).__init__(*args, **kwargs)
        self.fields["ProjectManagerID"].queryset = User.objects.filter(Role__RoleID=2)

class MilestonesForm(forms.ModelForm):
    class Meta:
        model = Milestones
        fields = ['MilestoneProjectID','MilestoneName','MilestoneDueDate','MilestoneStatus']

        widgets={
            'MilestoneProjectID': forms.Select(attrs={'class':'form-control','readonly':'readonly'}),
            'MilestoneName': forms.TextInput(attrs={'class':'form-control'}),
            'MilestoneDueDate': forms.SelectDateWidget(),
            'MilestoneStatus': forms.Select(attrs={'class':'form-control'}),
        }

        labels={
            'MilestoneProjectID' : 'Project',
            'MilestoneName': 'Name',
            'MilestoneDueDate': 'Due Date',
            'MilestoneStatus': 'Status',
        }

    def __init__(self,*args, **kwargs):
        projectid= kwargs.pop("projectID")
        super(MilestonesForm, self).__init__(*args, **kwargs)
        self.fields['MilestoneProjectID'].empty_label = None
        self.fields["MilestoneProjectID"].queryset = Project.objects.filter(ProjectID=projectid)

class TaskForm(forms.ModelForm):
    class Meta:
        model=Task
        fields="__all__"

        widgets={
            'TaskStatus': forms.Select(attrs={'class':'form-control'}),
            'TaskPriority': forms.Select(attrs={'class':'form-control'}),
            'TaskEmpID': forms.Select(attrs={'class':'form-control'}),
            'TaskName': forms.TextInput(attrs={'class':'form-control'}),
            'TaskDescription':forms.TextInput(attrs={'class':'form-control'}),
            'TaskMilestone': forms.Select(attrs={'class':'form-control','readonly':'readonly'}),
            'TaskTotalHours': forms.NumberInput(attrs={'class':'form-control'}),
            'TaskDependentOn': forms.Select(attrs={'class':'form-control'})
        }

        labels={
            'TaskStatus':'Status',
            'TaskPriority':'Priority',
            'TaskEmpID':'Assign To',
            'TaskName':'Task Name',
            'TaskMilestone':'Milestone',
            'TaskTotalHours':'Total Hours',
            'TaskDescription': 'Description',
            'TaskDependentOn': 'Dependent Task'
        }

    def __init__(self,*args, **kwargs):
        milestoneid= kwargs.pop("milestoneID")
        projectid= kwargs.pop("projectID")
        super(TaskForm, self).__init__(*args, **kwargs)
        self.fields["TaskMilestone"].queryset = Milestones.objects.filter(MilestoneID=milestoneid)
        self.fields["TaskMilestone"].empty_label = None
        self.fields["TaskEmpID"].queryset= AssignedProject.objects.filter(ProjectID__ProjectID=projectid)
        self.fields["TaskDependentOn"].queryset= Task.objects.filter(TaskMilestone__MilestoneID= milestoneid)

class NoteForm(forms.ModelForm):
    class Meta:
        model=Notes
        fields=['NotesEditorID','NotesName','NotesDescription']

        widgets={
            'NotesName': forms.TextInput(attrs={'class':'form-control'}),
            'NotesDescription': forms.Textarea(attrs={'class':'form-control'}),
            'NotesEditorID': forms.Select(attrs={'class':'form-control','readonly':'readonly'}),
        }

        labels={
            'NotesEditorID':'User',
            'NotesName':'Subject:',
            'NotesDescription':'Description',
        }

    def __init__(self,*args, **kwargs):
        userid = kwargs.pop("userID")
        super(NoteForm, self).__init__(*args, **kwargs)
        self.fields['NotesEditorID'].empty_label = None
        self.fields["NotesEditorID"].queryset = User.objects.filter(UserID=userid)

class ReportTaskForm(forms.ModelForm):

    hourworked = forms.IntegerField(widget=forms.NumberInput(attrs={'class': 'form-control'}))
    taskcompleted=forms.ChoiceField(choices=(('NA','-----'),('YES','YES'),('NO','NO')))

    class Meta:
        model=Task
        fields=['TaskName','TaskTotalHours','TaskHourWorked']

        labels={
            'TaskName': 'Task Name',
            'TaskTotalHours': 'Total Hour Alloted To work',
            'TaskHourWorked':'Total Hours You Worked Previously',
        }

    def __init__(self,*args, **kwargs):
        super(ReportTaskForm, self).__init__(*args, **kwargs)
        self.fields['TaskName'].widget.attrs={'class': 'form-control','readonly':'readonly'}
        self.fields['TaskHourWorked'].widget.attrs = {'class': 'form-control','readonly': 'readonly'}
        self.fields['TaskTotalHours'].widget.attrs = {'class': 'form-control','readonly': 'readonly'}
        self.fields['hourworked'].label = "Hour You Worked Now"
        self.fields['hourworked'].required = True
        self.fields['taskcompleted'].label = "Task Completed?"
        self.fields['taskcompleted'].required = True
        self.fields['taskcompleted'].widget.attrs = {'class': 'form-control'}

class SubTaskForm(forms.ModelForm):
    class Meta:
        model=SubTask
        fields="__all__"

        widgets={
            'SubTaskStatus': forms.Select(attrs={'class':'form-control'}),
            'SubTaskPriority': forms.Select(attrs={'class':'form-control'}),
            'SubTaskName': forms.TextInput(attrs={'class':'form-control'}),
            'SubTaskTask': forms.Select(attrs={'class':'form-control','readonly':'readonly'}),
            'SubTaskTotalHours':forms.NumberInput(attrs={'class':'form-control'}),
        }

        labels={
            'SubTaskStatus':'Status',
            'SubTaskPriority':'Priority',
            'SubTaskName':'Name',
            'SubTaskTask':'Task',
            'SubTaskTotalHours':'Total Hours',
        }

    def __init__(self,*args, **kwargs):
        taskid= kwargs.pop("taskID")
        super(SubTaskForm, self).__init__(*args, **kwargs)
        self.fields["SubTaskTask"].queryset = Task.objects.filter(TaskID=taskid)
        self.fields["SubTaskTask"].empty_label = None

class AddEventForm(forms.Form):
    summary = forms.CharField()
    address = forms.CharField()
    description = forms.CharField()
    startdate = forms.CharField()
    enddate = forms.CharField()

    def __init__(self, *args, **kwargs):
        super(AddEventForm, self).__init__(*args, **kwargs)
        self.fields['startdate'].widget.attrs.update({'type': 'date'})
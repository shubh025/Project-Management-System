from django.db import models

SecurityQuestion_Choices= (("What was your childhood nickname?","What was your childhood nickname?"),
                           ("What is the name of your favorite childhood friend?","What is the name of your favorite childhood friend?"),
                           ("In what city or town did your mother and father meet?","In what city or town did your mother and father meet?"),
                           ("What is the middle name of your oldest child?","What is the middle name of your oldest child?"),
                           ("What is your favorite team?","What is your favorite team?"),
                           ("What is your favorite movie?","What is your favorite movie?"),
                           ("What school did you attend for sixth grade?","What school did you attend for sixth grade?"),
                           ("What was the last name of your third grade teacher?","What was the last name of your third grade teacher?"),
                           ("In what town was your first job?","In what town was your first job?"),
                           ("What was the name of the company where you had your first job?","What was the name of the company where you had your first job?"),
                          ("What was the name of the hospital where you were born?","What was the name of the hospital where you were born?"),
                          ("Who is your childhood sports hero?","Who is your childhood sports hero?"))

# Create your models here.
class Roles(models.Model):
    RoleID= models.IntegerField(primary_key=True)
    RoleName= models.CharField(max_length=50)

    def __str__(self):
        return self.RoleName

class Teams(models.Model):
    TeamID= models.IntegerField(primary_key=True)
    TeamName= models.CharField(max_length=50)

    def __str__(self):
        return self.TeamName

class User(models.Model):
    UserID= models.AutoField(primary_key=True)
    LastName= models.CharField(max_length=25)
    FirstName=models.CharField(max_length=25)
    Email= models.EmailField(max_length=50,unique=True)
    Password= models.CharField(max_length=25)
    SecurityQuestion= models.CharField(max_length=250,choices=SecurityQuestion_Choices)
    SecurityAnswer= models.CharField(max_length=50)
    PhoneNumber= models.IntegerField()
    Role= models.ForeignKey(Roles,on_delete=models.CASCADE)
    ManagerID=models.ForeignKey('self',on_delete=models.CASCADE,null=True, blank=True)
    TeamID= models.ForeignKey(Teams,on_delete=models.CASCADE, null=True)
    UserImage= models.ImageField(blank=True, null=True)

    def __str__(self):
        return self.FirstName

class Client(models.Model):
    ClientID= models.AutoField(primary_key=True)
    ClientCompanyName = models.CharField(max_length=75, default='')
    ClientName= models.CharField(max_length=75)
    ClientEmail= models.EmailField(max_length=50, unique=True)
    ClientPhoneNumber= models.IntegerField()


class ProjectStatus(models.Model):
    PStatusID= models.AutoField(primary_key=True)
    StatusName= models.CharField(max_length=50)

    def __str__(self):
        return self.StatusName

class Project(models.Model):
    ProjectID= models.AutoField(primary_key=True)
    ProjectClientCompanyName = models.CharField(max_length=100, choices=Client.objects.values_list('ClientCompanyName','ClientCompanyName').distinct())
    ProjectClientName = models.CharField(max_length=100,choices=None)
    ProjectName= models.CharField(max_length=50)
    ProjectManagerID= models.ForeignKey(User,on_delete=models.CASCADE)
    ProjectStartDate= models.DateField()
    ProjectEndDate= models.DateField()
    ProjectStatus= models.ForeignKey(ProjectStatus,on_delete=models.CASCADE)

    def __str__(self):
        return self.ProjectName

class MilestoneStatus(models.Model):
    MilestoneStatusID = models.AutoField(primary_key=True)
    MilestoneStatusName = models.CharField(max_length=50)

    def __str__(self):
        return self.MilestoneStatusName

class Milestones(models.Model):
    MilestoneID = models.AutoField(primary_key=True)
    MilestoneName = models.CharField(max_length=50)
    MilestoneDueDate = models.DateField()
    MilestoneStatus = models.ForeignKey(MilestoneStatus,on_delete=models.CASCADE)
    MilestoneProjectID = models.ForeignKey(Project,on_delete=models.CASCADE)
    MilestoneTotalHours = models.IntegerField(default=0,null=True,blank=True)

    def __str__(self):
        return self.MilestoneName

class TaskStatus(models.Model):
    TaskStatusID= models.AutoField(primary_key=True)
    TaskStatusName= models.CharField(max_length=50)

    def __str__(self):
        return  self.TaskStatusName

class TaskPriority(models.Model):
    TaskPriorityID= models.AutoField(primary_key=True)
    TaskPriorityName= models.CharField(max_length=50)

    def __str__(self):
        return self.TaskPriorityName

class AssignedProject(models.Model):
    ProjectID = models.ForeignKey(Project,on_delete=models.CASCADE)
    UserID = models.ForeignKey(User, on_delete=models.CASCADE)

    def __str__(self):
        return str(self.UserID)

class Task(models.Model):
    TaskID= models.AutoField(primary_key=True)
    TaskMilestone = models.ForeignKey(Milestones,on_delete=models.CASCADE)
    TaskName= models.CharField(max_length=50)
    TaskDescription = models.TextField(max_length=500,null=True, blank=True)
    TaskDependentOn = models.ForeignKey('Task', on_delete=models.CASCADE, null=True, blank=True)
    TaskEmpID = models.ForeignKey(AssignedProject, on_delete=models.CASCADE)
    TaskTotalHours= models.IntegerField(default='')
    TaskHourWorked = models.IntegerField(default=0)
    TaskPriority = models.ForeignKey(TaskPriority, on_delete=models.CASCADE)
    TaskStatus = models.ForeignKey(TaskStatus, on_delete=models.CASCADE)

    def __str__(self):
        return self.TaskName

class SubTask(models.Model):
    SubTaskID = models.AutoField(primary_key=True)
    SubTaskTask = models.ForeignKey(Task,on_delete=models.CASCADE,null=True,blank=True)
    SubTaskName = models.CharField(max_length=50)
    SubTaskTotalHours = models.IntegerField()
    SubTaskStatus = models.ForeignKey(TaskStatus, on_delete=models.CASCADE)
    SubTaskPriority = models.ForeignKey(TaskPriority, on_delete=models.CASCADE)

class Notes(models.Model):
    NotesID=models.AutoField(primary_key=True)
    NotesName=models.CharField(max_length=50)
    NotesDescription = models.TextField(max_length=500)
    NotesEditorID = models.ForeignKey(User,on_delete=models.CASCADE)

    class Meta:
        get_latest_by = 'NotesID'

class ChatMessenger(models.Model):
    Created = models.DateTimeField(auto_now_add=True)
    MessageSentTo = models.ForeignKey(User, on_delete=models.CASCADE, related_name='messagesentto', default='')
    MessageSentFrom = models.ForeignKey(User, on_delete=models.CASCADE, related_name='messagesentfrom', default='')
    Message = models.CharField(max_length=200)

    def __str__(self):
        return self.Message

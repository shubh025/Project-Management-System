from django.shortcuts import render
from django.http import HttpResponseRedirect, HttpResponse,JsonResponse
from ProjectManagementSystem.models import User, Client,Project, AssignedProject, Teams, Milestones, Task, SubTask, Notes, ProjectStatus, TaskStatus, ChatMessenger, MilestoneStatus
from ProjectManagementSystem.forms import UserForm, ClientForm, ProjectForm, MilestonesForm, TaskForm, NoteForm, ReportTaskForm, SubTaskForm, AddEventForm
from django.db.models import Sum
from collections import Counter
import json
from ProjectManagementSystem.google import google

def adminlogin_required(lg,rl):
    try:
        if lg == True and rl == '1':
            return True
        else:
            HttpResponseRedirect('/login/')
    except KeyError:
        HttpResponseRedirect('/login/')

def managerlogin_required(lg,rl):
    try:
        if lg == True and rl == '2':
            return True
        else:
            HttpResponseRedirect('/login/')
    except KeyError:
        HttpResponseRedirect('/login/')

def memberlogin_required(lg,rl):
    try:
        if lg == True and rl == '3':
            return True
        else:
            HttpResponseRedirect('/login/')
    except KeyError:
        HttpResponseRedirect('/login/')

def login(request):
    if request.method == 'POST':
        role = request.POST.get('role',False)
        userID = request.POST.get('userID', False)
        password = request.POST.get('password',False)
        try:
            user = User.objects.get(UserID=userID,Role__RoleID=role,Password=password)
            if user is not None:
                request.session['logged_in']=True
                request.session['Role']=role
                request.session['UserID'] = user.UserID
                if role == '1':
                    return HttpResponseRedirect("/projectinfo/")
                elif role == '2':
                    return HttpResponseRedirect("/managerhome/")
                elif role == '3':
                    return HttpResponseRedirect("/memberhome/")
            else:
                return render(request,"login.html",{"login":"unsuccessful"})
        except:
            return render(request, "login.html", {"login": "unsuccessful"})
    else:
        return render(request,"login.html")

def logout(request):
    try:
        request.session['logged_in']=False
        request.session['Role']=""
        request.session['UserID']=""
    except KeyError:
        pass
    return render(request, "login.html")

def Usersinfo(request):
    if adminlogin_required(request.session['logged_in'], request.session['Role']):
        user = User.objects.all()
        admin= User.objects.get(UserID=request.session['UserID'])
        return render(request, 'usersinfo.html', {'user':admin,'employees': user,'sidebar':'1'})

def register(request):
    if adminlogin_required(request.session['logged_in'],request.session['Role']):
        admin= User.objects.get(UserID=request.session['UserID'])
        # if this is a POST request we need to process the form data
        if request.method == 'POST':
            # create a form instance and populate it with data from the request:
            form = UserForm(request.POST,request.FILES)
            # check whether it's valid:
            if form.is_valid():
                form.save()
                email = form.cleaned_data["Email"]
                user = User.objects.get(Email=email)
                return render(request, "showlogincredentials.html", {"data": user,'user':admin})
        else:
            form = UserForm()
        return render(request, 'register.html', {'form': form,'user':admin})

def edituser(request,userid=None):
    if adminlogin_required(request.session['logged_in'], request.session['Role']):
        admin= User.objects.get(UserID=request.session['UserID'])
        if userid:
            userinfo = User.objects.get(UserID=userid)
        # if this is a POST request we need to process the form data
        if request.method == 'POST':
            # create a form instance and populate it with data from the request:
            form = UserForm(request.POST,request.FILES, instance=userinfo)
            # check whether it's valid:
            if form.is_valid():
                form.save()
                users = User.objects.all()
                return render(request, 'usersinfo.html', {'employees': users,'sidebar':'1','user':admin})

        else:
            form = UserForm(instance=userinfo)
        return render(request, 'edituser.html', {'form': form, 'userid': userid,'sidebar':'1','user':admin})

def deleteuser(request, userid):
    if adminlogin_required(request.session['logged_in'], request.session['Role']):
        User.objects.get(UserID=userid).delete()
        user = User.objects.all()
        return render(request, 'usersinfo.html', {'employees': user,'sidebar':'1'})

def showlogincredentials(request):
    if adminlogin_required(request.session['logged_in'], request.session['Role']):
        if 'reg&addanother' in request.POST:
            return HttpResponseRedirect("/register/")
        elif 'done' in request.POST:
            return HttpResponseRedirect("/Usersinfo/")

def addclient(request):
    if adminlogin_required(request.session['logged_in'], request.session['Role']):
        # if this is a POST request we need to process the form data
        if request.method == 'POST':
            # create a form instance and populate it with data from the request:
            form = ClientForm(request.POST)
            # check whether it's valid:
            if form.is_valid():
                form.save()
                client= Client.objects.all()
                return render(request,'clientinfo.html',{'client':client})
        else:
            form = ClientForm()
        return render(request, 'addclientmodal.html', {'form': form})

def clientinfo(request):
    if adminlogin_required(request.session['logged_in'], request.session['Role']):
        client= Client.objects.all()
        user= User.objects.get(UserID=request.session['UserID'])
        return render(request,'clientinfo.html',{'client':client,'user':user,'sidebar':'2'})

def EditClient(request,clientid=None):
    if adminlogin_required(request.session['logged_in'], request.session['Role']):
        user= User.objects.get(UserID=request.session['UserID'])
        if clientid:
            clientinfo = Client.objects.get(ClientID=clientid)
        # if this is a POST request we need to process the form data
        if request.method == 'POST':
            # create a form instance and populate it with data from the request:
            form = ClientForm(request.POST,instance=clientinfo)
            # check whether it's valid:
            if form.is_valid():
                form.save()
                client = Client.objects.all()
                return render(request, 'clientinfo.html', {'user':user,'client': client,'sidebar':'2'})
        else:
            form = ClientForm(instance=clientinfo)
        return render(request, 'editclient.html', {'user':user,'form': form,'clientid':clientid,'sidebar':'2'})

def DeleteClient(request, clientid):
    if adminlogin_required(request.session['logged_in'], request.session['Role']):
        Client.objects.get(ClientID=clientid).delete()
        client=Client.objects.all()
        return render(request,'clientinfo.html',{'client':client,'sidebar':'2'})

def projectinfo(request):
    if adminlogin_required(request.session['logged_in'], request.session['Role']):
        projects= Project.objects.all()
        user= User.objects.get(UserID=request.session['UserID'])
        projectcount= projects.count()
        usercount= User.objects.all().count()
        clientcount= Client.objects.all().count()
        clients= Client.objects.all()
        return render(request, 'adminhome.html', {'clients':clients,'projectcount':projectcount,'projects':projects, 'user':user,'usercount':usercount,'clientcount':clientcount})

def addproject(request):
    if adminlogin_required(request.session['logged_in'], request.session['Role']):
        user= User.objects.get(UserID=request.session['UserID'])
        if request.method == 'POST':
            # create a form instance and populate it with data from the request:
            form = ProjectForm(request.POST)
            # check whether it's valid:
            if form.is_valid():
                print("form valid")
                form.save()
                projects = Project.objects.all()
                projectcount = projects.count()
                usercount = User.objects.all().count()
                clientcount = Client.objects.all().count()
                return render(request, 'adminhome.html', {'user':user,'projects': projects,'projectcount':projectcount,'usercount':usercount,'clientcount':clientcount})
            print(form.errors)
        else:
            form = ProjectForm()
        return render(request, 'addprojectmodal.html', {'form': form})

def getclients(request):
    companyname = request.GET.get('companyname')
    clients = Client.objects.filter(ClientCompanyName=companyname)
    return render(request,'load_clients.html', {'clients':clients})

def adminhome(request):
    if adminlogin_required(request.session['logged_in'], request.session['Role']):
        return render(request, "adminhome.html")

def managerhome(request):
    if managerlogin_required(request.session['logged_in'], request.session['Role']):
        projects = Project.objects.filter(ProjectManagerID=request.session['UserID'])
        if projects:
            firstprojectID= projects[0].ProjectID
            project = Project.objects.get(ProjectID=firstprojectID)
            milestones = Milestones.objects.filter(MilestoneProjectID__ProjectID=firstprojectID)
            milestonesstatuslist = Milestones.objects.filter(MilestoneProjectID__ProjectID=firstprojectID).values_list(
                "MilestoneStatus__MilestoneStatusName", flat=True)
            milestonesstatuscount = dict(Counter(milestonesstatuslist))
            milestonesstatuscountlist = [[key, value] for key, value in milestonesstatuscount.items()]
            milestonesstatuscountlist.insert(0, ['Milestones', 'Milestonestatus'])
            milestoneprogresslist = []
            totalprogress=0
            count=0
            for milestone in milestones:
                tasks = Task.objects.filter(TaskMilestone=milestone)
                totaltask = tasks.count()
                totaltaskcompleted = tasks.filter(TaskStatus__TaskStatusName__contains='Complete').count()
                if totaltask != 0:
                    progress = round((totaltaskcompleted / totaltask) * 100, 2)
                    totalprogress = progress + totalprogress
                    count = count+1
                    progress = str(progress) + '%'
                    milestoneprogresslist.append([milestone.MilestoneID, progress])
                else:
                    milestoneprogresslist.append([milestone.MilestoneID, 'No Task Added'])
            milestoneprogresslist = dict(milestoneprogresslist)
            projectprogress=0
            if count!=0:
                projectprogress = totalprogress/count
            projectprogress = str(round(projectprogress,2))+'%'
            return render(request, 'managerhome.html', {'myprojects': projects, 'sidebar':firstprojectID,'milestoneprogresslist':milestoneprogresslist,'project':project,"milestones":milestones,"milestonestatuscount":json.dumps(milestonesstatuscountlist),'projectprogress':projectprogress})
        else:
            return render(request,'managerhome.html',{'myprojects':projects})

def managerDashboard(request,projectid=None):
    if managerlogin_required(request.session['logged_in'], request.session['Role']):
        project= Project.objects.get(ProjectID=projectid)
        projects = Project.objects.filter(ProjectManagerID=request.session['UserID'])
        milestones= Milestones.objects.filter(MilestoneProjectID__ProjectID=projectid)
        milestonesstatuslist= Milestones.objects.filter(MilestoneProjectID__ProjectID=projectid).values_list("MilestoneStatus__MilestoneStatusName",flat=True)
        milestonesstatuscount = dict(Counter(milestonesstatuslist))
        milestonesstatuscountlist = [[key, value] for key, value in milestonesstatuscount.items()]
        milestonesstatuscountlist.insert(0, ['Milestones', 'Milestonestatus'])
        milestoneprogresslist = []
        totalprogress = 0
        count = 0
        for milestone in milestones:
            tasks = Task.objects.filter(TaskMilestone=milestone)
            totaltask = tasks.count()
            totaltaskcompleted = tasks.filter(TaskStatus__TaskStatusName__contains='Complete').count()
            if totaltask != 0:
                progress = round((totaltaskcompleted / totaltask) * 100, 2)
                totalprogress = progress + totalprogress
                count = count + 1
                progress = str(progress) + '%'
                milestoneprogresslist.append([milestone.MilestoneID, progress])
            else:
                milestoneprogresslist.append([milestone.MilestoneID, 'No Task Added'])
        milestoneprogresslist = dict(milestoneprogresslist)
        projectprogress=0
        if count!=0:
            projectprogress = totalprogress / count
        projectprogress = str(round(projectprogress,2)) + '%'
        return render(request,'managerhome.html',{'project':project, 'sidebar': projectid,'myprojects':projects,"milestones":milestones,"milestonestatuscount":json.dumps(milestonesstatuscountlist),'milestoneprogresslist':milestoneprogresslist,'projectprogress':projectprogress})

def taskchart(request,milestoneid=None):
    if managerlogin_required(request.session['logged_in'], request.session['Role']):
        milestone = Milestones.objects.get(MilestoneID=milestoneid)
        tasks = Task.objects.filter(TaskMilestone__MilestoneID=milestoneid)
        taskstatuslist = tasks.values_list("TaskStatus__TaskStatusName",flat=True)
        taskstatuscount = dict(Counter(taskstatuslist))
        taskstatuscountlist = [ [key,value] for key,value in taskstatuscount.items()]
        taskstatuscountlist.insert(0,['task','taskstatus'])
        return render(request,"taskchart.html",{"taskstatuscount":json.dumps(taskstatuscountlist),'milestone':milestone, 'tasks' : tasks})

def load_users(request):
    if managerlogin_required(request.session['logged_in'],request.session['Role']):
        teamID = request.GET.get('teamID')
        notassigned = []
        users = User.objects.filter(ManagerID=request.session['UserID'],TeamID__TeamID=teamID)
        for user in users:
            assigned = AssignedProject.objects.filter(UserID__UserID=user.UserID)
            if not assigned:
                notassigned.append(user)
        return render(request, "userdata.html", {'users':notassigned})

def myteampage(request):
    if managerlogin_required(request.session['logged_in'],request.session['Role']):
        managerID = request.session['UserID']
        allprojects = Project.objects.filter(ProjectManagerID=managerID)
        if allprojects:
            firstProjectID= allprojects[0].ProjectID
            usersID = AssignedProject.objects.filter(ProjectID__ProjectID=firstProjectID).values_list('UserID',flat=True)
            users=User.objects.filter(UserID__in=usersID)
            teams=users.values_list('TeamID__TeamName', flat=True).distinct()
            nousers = True
            if users is None:
                nousers = False
            return render(request,"myteam.html",{'users':users,'projects':allprojects,'nousers':nousers,'teams':teams,'sidebar':firstProjectID,'navbar':'2'})
        else:
            return render(request,"myteam.html",{'projects':allprojects,'navbar':'2'})

def myteamdetail(request, projectid=None):
    if managerlogin_required(request.session['logged_in'],request.session['Role']):
        managerID = request.session['UserID']
        allprojects = Project.objects.filter(ProjectManagerID=managerID)
        usersID = AssignedProject.objects.filter(ProjectID__ProjectID=projectid).values_list('UserID',flat=True)
        users=User.objects.filter(UserID__in=usersID)
        teams=users.values_list('TeamID__TeamName', flat=True).distinct()
        nousers = True
        if users is None:
            nousers=False
        return render(request,"myteam.html",{'users':users,'projects':allprojects,'nousers':nousers,'teams':teams,'sidebar':projectid,'navbar':'2'})

def assignprojects(request, projectid=None):
    if managerlogin_required(request.session['logged_in'],request.session['Role']):
        if request.method == 'POST':
            usersid = request.POST.getlist('username')
            print(usersid)
            for userID in usersid:
                user = User.objects.get(UserID=userID)
                project = Project.objects.get(ProjectID=projectid)
                assignproject = AssignedProject()
                assignproject.UserID=user
                assignproject.ProjectID=project
                assignproject.save()
            response = myteamdetail(request,projectid=projectid)
            return response
        else:
            project= Project.objects.get(ProjectID=projectid)
            teams = Teams.objects.all()
        return render(request,'assignprojectsmodal.html',{'project':project,"teams":teams,'navbar':'1'})

def removeuserfromproject(request, userid):
    if managerlogin_required(request.session['logged_in'], request.session['Role']):
        projectid = AssignedProject.objects.get(UserID__UserID=userid).ProjectID_id
        AssignedProject.objects.get(UserID__UserID=userid).delete()
        response=myteamdetail(request,projectid)
        return HttpResponse(response)

def milestonesandtasks(request):
    if managerlogin_required(request.session['logged_in'], request.session['Role']):
        managerid = request.session['UserID']
        allprojects = Project.objects.filter(ProjectManagerID=managerid)
        if allprojects:
            firstprojectID= allprojects[0].ProjectID
            milestones = Milestones.objects.filter(MilestoneProjectID__ProjectID=firstprojectID)
            milestoneprogresslist = []
            for milestone in milestones:
                tasks= Task.objects.filter(TaskMilestone = milestone)
                totaltask = tasks.count()
                totaltaskcompleted = tasks.filter(TaskStatus__TaskStatusName__contains='Complete').count()
                if totaltask != 0:
                    progress = str(round((totaltaskcompleted / totaltask) * 100,2)) + '%'
                    milestoneprogresslist.append([milestone.MilestoneID,progress])
                else:
                    milestoneprogresslist.append([milestone.MilestoneID,'No Task Added'])
            milestoneprogresslist = dict(milestoneprogresslist)
            form = MilestonesForm(projectID=firstprojectID)
            nomilestone = 'False'
            if milestones == None:
                nomilestone = 'True'
            return render(request, "milestonesandtasks.html", {'projects': allprojects,'milestones':milestones,'form':form,'nomilestone': nomilestone,'navbar': '3','sidebar':int(firstprojectID),'milestoneprogresslist':milestoneprogresslist})
        else:
            return render(request, "milestonesandtasks.html", {'projects': allprojects})

def milestonesandtasksdetails(request,projectid=None, error='False'):
    if managerlogin_required(request.session['logged_in'], request.session['Role']):
        managerid = request.session['UserID']
        allprojects = Project.objects.filter(ProjectManagerID=managerid)
        milestones = Milestones.objects.filter(MilestoneProjectID__ProjectID=projectid)
        milestoneprogresslist = []
        for milestone in milestones:
            tasks = Task.objects.filter(TaskMilestone=milestone)
            totaltask = tasks.count()
            totaltaskcompleted = tasks.filter(TaskStatus__TaskStatusName__contains='Complete').count()
            if totaltask != 0:
                progress = str(round((totaltaskcompleted / totaltask) * 100, 2)) + '%'
                milestoneprogresslist.append([milestone.MilestoneID, progress])
            else:
                milestoneprogresslist.append([milestone.MilestoneID, 'No Task Added'])
        milestoneprogresslist = dict(milestoneprogresslist)
        form = MilestonesForm(projectID=projectid)
        nomilestone = 'False'
        if milestones==None:
            nomilestone = 'True'
        return render(request, "milestonesandtasks.html", {'projects': allprojects, 'error':error, 'milestones':milestones, 'nomilestone': nomilestone, 'form':form,'sidebar':int(projectid),'navbar': '3','milestoneprogresslist':milestoneprogresslist})

def addmilestones(request):
    if managerlogin_required(request.session['logged_in'], request.session['Role']):
        managerid = request.session['UserID']
        if request.method=='POST':
            projectid = request.POST.get('MilestoneProjectID')
            form = MilestonesForm(request.POST,projectID=projectid)
            projectenddate= Project.objects.filter(ProjectID=projectid).values_list('ProjectEndDate',flat=True)
            projectstartdate = Project.objects.filter(ProjectID=projectid).values_list('ProjectStartDate', flat=True)
            if form.is_valid():
                duedate = form.cleaned_data['MilestoneDueDate']
                if duedate.__gt__(projectstartdate[0]) and duedate.__lt__(projectenddate[0]):
                    form.save()
                    link = "/" + str(projectid) + "/milestones&tasksdetails"
                    return HttpResponseRedirect(link)
                else:
                    response = milestonesandtasksdetails(request,projectid,error='True')
                    return response

def tasksdetails(request,milestoneid=None, projectid=None):
    if managerlogin_required(request.session['logged_in'], request.session['Role']):
        managerid = request.session['UserID']
        allprojects = Project.objects.filter(ProjectManagerID=managerid)
        tasks= Task.objects.filter(TaskMilestone= milestoneid)
        form = TaskForm(milestoneID=milestoneid,projectID=projectid)
        return render(request, "tasksdetails.html",{'navbar':'3','projects': allprojects,'tasks': tasks,'form':form, 'milestoneid':milestoneid,'sidebar':projectid})

def addtasks(request,milestoneid=None, projectid=None):
    if managerlogin_required(request.session['logged_in'], request.session['Role']):
        managerid = request.session['UserID']
        allprojects = Project.objects.filter(ProjectManagerID=managerid)
        if request.method=='POST':
            form = TaskForm(request.POST,milestoneID=milestoneid, projectID=projectid)
            milestone= Milestones.objects.get(MilestoneID=milestoneid)
            if form.is_valid():
                taskhours= form.cleaned_data['TaskTotalHours']
                othertaskhours= Task.objects.filter(TaskMilestone=milestoneid).aggregate(Sum('TaskTotalHours'))
                totaltaskhours=0
                if othertaskhours['TaskTotalHours__sum'] != None:
                    totaltaskhours= othertaskhours['TaskTotalHours__sum'] + taskhours
                else:
                    totaltaskhours = taskhours
                milestone.MilestoneTotalHours = totaltaskhours
                milestone.save()
                form.save()
                link = "/" + str(milestoneid) + "/" + str(projectid) + "/tasksdetails"
                return HttpResponseRedirect(link)

def load_task(request, taskid=None, milestoneid=None, projectid=None):
    if managerlogin_required(request.session['logged_in'],request.session['Role']):
        task = Task.objects.get(TaskID=taskid)
        milestone = Milestones.objects.get(MilestoneID=milestoneid)
        previoustaskhour = Task.objects.filter(TaskID=taskid).values_list("TaskTotalHours", flat=True)
        if request.method == 'POST':
            form = TaskForm(request.POST, instance=task,milestoneID=milestoneid, projectID=projectid)
            if form.is_valid():
                newtaskhour = form.cleaned_data["TaskTotalHours"]
                aggregatetaskhours = (Task.objects.filter(TaskMilestone=milestoneid)).aggregate(Sum('TaskTotalHours'))
                milestone.MilestoneTotalHours = aggregatetaskhours['TaskTotalHours__sum'] - previoustaskhour[0] + newtaskhour
                milestone.save()
                form.save()
                link = "/" + str(milestoneid) + "/" + str(projectid) + "/tasksdetails"
                return HttpResponseRedirect(link)
        else:
            form = TaskForm(instance=task, milestoneID=milestoneid, projectID=projectid)
        return render(request, "modal.html", {'editform': form, 'taskid': taskid, 'milestoneid' : milestoneid, 'projectid':projectid})


def deleteTask(request, taskid=None, milestoneid=None, projectid=None):
    if managerlogin_required(request.session['logged_in'], request.session['Role']):
        Task.objects.get(TaskID=taskid).delete()
        tasks = Task.objects.filter(TaskMilestone=milestoneid)
        form = TaskForm(milestoneID=milestoneid, projectID=projectid)
        managerid = request.session['UserID']
        allprojects = Project.objects.filter(ProjectManagerID=managerid)
        milestone = Milestones.objects.get(MilestoneID=milestoneid)
        milestone.MilestoneTotalHours = tasks.aggregate(Sum('TaskTotalHours'))['TaskTotalHours__sum']
        milestone.save()
        return render(request, "tasksdetails.html", {'navbar':'3','tasks': tasks, 'form': form, 'milestoneid': milestoneid, "sidebar":projectid, "projects":allprojects})

def subtaskdetails(request,taskid=None, projectid=None):
    if managerlogin_required(request.session['logged_in'], request.session['Role']):
        managerid = request.session['UserID']
        allprojects = Project.objects.filter(ProjectManagerID=managerid)
        subtasks = SubTask.objects.filter(SubTaskTask=taskid)
        form = SubTaskForm(taskID= taskid)
        return render(request, "subtaskdetails.html",{'navbar':'3','projects': allprojects,'subtasks': subtasks,'form':form, 'taskid':taskid,'sidebar':projectid})

def addsubtasks(request,taskid=None, projectid=None):
    if managerlogin_required(request.session['logged_in'], request.session['Role']):
        if request.method=='POST':
            form = SubTaskForm(request.POST,taskID=taskid)
            task= Task.objects.get(TaskID=taskid)
            previoustaskhours= task.TaskTotalHours
            taskMilestone= Milestones.objects.get(MilestoneID= task.TaskMilestone.MilestoneID)
            if form.is_valid():
                subtaskhours= form.cleaned_data['SubTaskTotalHours']
                othersubtaskhours= SubTask.objects.filter(SubTaskTask=taskid).aggregate(Sum('SubTaskTotalHours'))
                if othersubtaskhours['SubTaskTotalHours__sum'] != None:
                    totalsubtaskhours= othersubtaskhours['SubTaskTotalHours__sum'] + subtaskhours
                else:
                    totalsubtaskhours = subtaskhours
                task.TaskTotalHours = totalsubtaskhours
                aggregatetaskhours = (Task.objects.filter(TaskMilestone= task.TaskMilestone.MilestoneID)).aggregate(Sum('TaskTotalHours'))
                taskMilestone.MilestoneTotalHours= aggregatetaskhours['TaskTotalHours__sum'] - previoustaskhours + task.TaskTotalHours
                task.save()
                taskMilestone.save()
                form.save()
                link = "/" + str(taskid) + "/" + str(projectid) + "/subtaskdetails"
                return HttpResponseRedirect(link)

def load_subtask(request, subtaskid=None, taskid=None, projectid=None):
    if managerlogin_required(request.session['logged_in'],request.session['Role']):
        subtask = SubTask.objects.get(SubTaskID=subtaskid)
        task = Task.objects.get(TaskID=taskid)
        previoussubtaskhour = SubTask.objects.filter(SubTaskID=subtaskid).values_list("SubTaskTotalHours", flat=True)
        previoustaskhours = task.TaskTotalHours
        taskMilestone = Milestones.objects.get(MilestoneID=task.TaskMilestone.MilestoneID)
        if request.method == 'POST':
            form = SubTaskForm(request.POST, instance=subtask,taskID=taskid)
            if form.is_valid():
                newsubtaskhour = form.cleaned_data["SubTaskTotalHours"]
                aggregatesubtaskhours = (SubTask.objects.filter(SubTaskTask=taskid)).aggregate(Sum('SubTaskTotalHours'))
                task.TaskTotalHours = aggregatesubtaskhours['SubTaskTotalHours__sum'] - previoussubtaskhour[0] + newsubtaskhour
                aggregatetaskhours = (Task.objects.filter(TaskMilestone=task.TaskMilestone.MilestoneID)).aggregate(Sum('TaskTotalHours'))
                taskMilestone.MilestoneTotalHours = aggregatetaskhours['TaskTotalHours__sum'] - previoustaskhours + task.TaskTotalHours
                task.save()
                taskMilestone.save()
                form.save()
                link = "/" + str(taskid) + "/" + str(projectid) + "/subtaskdetails"
                return HttpResponseRedirect(link)
        else:
            form = SubTaskForm(instance=subtask, taskID=taskid)
        return render(request, "subtaskmodal.html", {'editform': form, 'subtaskid': subtaskid, 'taskid' : taskid, 'projectid':projectid})

def deletesubtask(request, subtaskid=None, taskid=None, projectid=None):
    if managerlogin_required(request.session['logged_in'], request.session['Role']):
        SubTask.objects.get(SubTaskID=subtaskid).delete()
        subtasks = SubTask.objects.filter(SubTaskTask=taskid)
        form = SubTaskForm(taskID=taskid)
        managerid = request.session['UserID']
        allprojects = Project.objects.filter(ProjectManagerID=managerid)
        task = Task.objects.get(TaskID=taskid)
        previoustaskhours = task.TaskTotalHours
        taskMilestone = Milestones.objects.get(MilestoneID=task.TaskMilestone.MilestoneID)
        task.TaskTotalHours = subtasks.aggregate(Sum('SubTaskTotalHours'))['SubTaskTotalHours__sum']
        aggregatetaskhours = (Task.objects.filter(TaskMilestone=task.TaskMilestone.MilestoneID)).aggregate(Sum('TaskTotalHours'))
        taskMilestone.MilestoneTotalHours = aggregatetaskhours['TaskTotalHours__sum'] - previoustaskhours + task.TaskTotalHours
        task.save()
        taskMilestone.save()
        return render(request, "subtaskdetails.html", {'navbar':'3','subtasks': subtasks, 'form': form, 'taskid': taskid, "sidebar":projectid, "projects":allprojects})

def load_milestone(request,milestoneid=None, projectid=None):
    if managerlogin_required(request.session['logged_in'], request.session['Role']):
        print(projectid)
        print(milestoneid)
        managerid = request.session['UserID']
        milestonedetails= Milestones.objects.get(MilestoneID=milestoneid)
        print(milestonedetails)
        if request.method == 'POST':
            form = MilestonesForm(request.POST, instance=milestonedetails,projectID=projectid)
            projectenddate = Project.objects.filter(ProjectID=projectid).values_list('ProjectEndDate', flat=True)
            projectstartdate = Project.objects.filter(ProjectID=projectid).values_list('ProjectStartDate', flat=True)
            if form.is_valid():
                duedate = form.cleaned_data['MilestoneDueDate']
                if duedate.__gt__(projectstartdate[0]) and duedate.__lt__(projectenddate[0]):
                    form.save()
                    link = "/" + str(projectid) + "/milestones&tasksdetails"
                    return HttpResponseRedirect(link)
                else:
                    response = milestonesandtasksdetails(request, projectid, error='True')
                    return response
        else:
            form = MilestonesForm(instance=milestonedetails,projectID=projectid)
        return render(request, "editmilestonemodal.html", {'editform': form,'milestoneid': milestoneid, 'projectid': projectid})

def deleteMilestone(request,milestoneid=None, projectid=None):
    if managerlogin_required(request.session['logged_in'], request.session['Role']):
        Milestones.objects.get(MilestoneID=milestoneid).delete()
        managerid = request.session['UserID']
        allprojects = Project.objects.filter(ProjectManagerID=managerid)
        milestones = Milestones.objects.filter(MilestoneProjectID= projectid)
        form = MilestonesForm(projectID=projectid)
        nomilestone = 'False'
        if milestones == None:
            nomilestone = 'True'
        return render(request, "milestonesandtasks.html", {'projects': allprojects,'milestones': milestones, 'nomilestone': nomilestone,
                       'form': form, 'sidebar': int(projectid), 'navbar': '3'})

def notes(request):
    if request.session['logged_in']:
        userid = request.session['UserID']
        role= request.session['Role']
        if role == '2':
            base_template_name = 'managernavbar.html'
        else:
            base_template_name = 'membernavbar.html'
        notes = Notes.objects.filter(NotesEditorID__UserID=userid)
        if notes:
            firstnote= notes[0]
            noteid= firstnote.NotesID
            return render(request,"notes.html",{"notes":notes,"usernote":firstnote, "noteid":noteid,'navbar': '4','base_template_name':base_template_name})
        else:
            return render(request,"notes.html",{"notes":notes,'navbar': '4','base_template_name':base_template_name})


def notesdetails(request, noteid=None):
    if request.session['logged_in']:
        userid = request.session['UserID']
        role= request.session['Role']
        if role == '2':
            base_template_name = 'managernavbar.html'
        else:
            base_template_name = 'membernavbar.html'
        notes = Notes.objects.filter(NotesEditorID__UserID=userid)
        note = Notes.objects.get(NotesID=noteid)
        return render(request, "notes.html", {"usernote":note, "notes":notes, 'noteid':int(noteid),'navbar': '4','base_template_name':base_template_name})

def addanote(request):
    if request.session['logged_in']:
        userid = request.session['UserID']
        role= request.session['Role']
        if role == '2':
            base_template_name = 'managernavbar.html'
        else:
            base_template_name = 'membernavbar.html'
        if request.method=='POST':
            form= NoteForm(request.POST,userID=userid)
            if form.is_valid():
                form.save()
                notes = Notes.objects.filter(NotesEditorID__UserID=userid)
                lastnote= Notes.objects.latest()
                lastnoteid= lastnote.NotesID
                return render(request, "notes.html", {'usernote':lastnote,'noteid':lastnoteid,"notes": notes,'navbar': '4','base_template_name':base_template_name})

        else:
            form = NoteForm(userID=userid)
            return render(request,"addanotemodal.html",{'form':form})

def editanote(request,noteid=None):
    if request.session['logged_in']:
        userid = request.session['UserID']
        role= request.session['Role']
        if role == '2':
            base_template_name = 'managernavbar.html'
        else:
            base_template_name = 'membernavbar.html'
        note= Notes.objects.get(NotesID=noteid)
        if request.method=='POST':
            form= NoteForm(request.POST,instance=note,userID=userid)
            if form.is_valid():
                form.save()
                notes = Notes.objects.filter(NotesEditorID__UserID=userid)
                return render(request, "notes.html", {"usernote":note, "notes": notes,'noteid':noteid,'navbar': '4','base_template_name':base_template_name})

        else:
            form = NoteForm(userID=userid, instance=note)
            return render(request,"editanotemodal.html",{'form':form, 'noteid':noteid})

def deleteNote(request, noteid=None):
    if request.session['logged_in']:
        Notes.objects.get(NotesID=noteid).delete()
        userid = request.session['UserID']
        role= request.session['Role']
        if role == '2':
            base_template_name = 'managernavbar.html'
        else:
            base_template_name = 'membernavbar.html'
        notes = Notes.objects.filter(NotesEditorID__UserID=userid)
        if notes:
            firstnote = notes[0]
            noteid = firstnote.NotesID
            return render(request, "notes.html",
                          {"notes": notes, "usernote": firstnote, "noteid": noteid, 'navbar': '4','base_template_name':base_template_name})
        else:
            return render(request, "notes.html", {"notes": notes, 'navbar': '4','base_template_name':base_template_name})

def memberhome(request):
    if memberlogin_required(request.session['logged_in'], request.session['Role']):
        taskassigned= Task.objects.filter(TaskEmpID__UserID= request.session['UserID'])
        taskstatus=['OVERDUE','NOT STARTED','IN PROGRESS','COMPLETE']
        return render(request,"memberhome.html",{'tasks':taskassigned,'taskstatus':taskstatus})

def starttask(request, taskid=None):
    if memberlogin_required(request.session['logged_in'], request.session['Role']):
        task = Task.objects.get(TaskID=taskid)
        error = False
        if task.TaskDependentOn == None or task.TaskDependentOn.TaskStatus.TaskStatusID == 3:
            print("yes")
            milestone = task.TaskMilestone
            milestone.MilestoneStatus = MilestoneStatus.objects.get(MilestoneStatusName = 'IN PROGRESS')
            milestone.save()
            project = milestone.MilestoneProjectID
            project.ProjectStatus = ProjectStatus.objects.get(StatusName='ACTIVE')
            project.save()
            task.TaskStatus = TaskStatus.objects.get(TaskStatusID=2)
            task.save()
        taskassigned = Task.objects.filter(TaskEmpID__UserID=request.session['UserID'])
        taskstatus = ['OVERDUE','NOT STARTED','IN PROGRESS','COMPLETE']
        return render(request, "memberhome.html", {'tasks': taskassigned, 'taskstatus': taskstatus, 'error':error})

def reporttask(request, taskid=None):
    if memberlogin_required(request.session['logged_in'], request.session['Role']):
        task = Task.objects.get(TaskID=taskid)
        if request.method=="POST":
            form = ReportTaskForm(request.POST)
            if form.is_valid():
                taskcompleted = form.cleaned_data['taskcompleted']
                totalhouralloted = task.TaskTotalHours
                previoushourworked = task.TaskHourWorked
                currenthourworked = form.cleaned_data['hourworked']
                if taskcompleted == 'YES':
                    print("yes")
                    task.TaskHourWorked = previoushourworked + currenthourworked
                    task.TaskStatus = TaskStatus.objects.get(TaskStatusID=3)
                    task.save()
                elif taskcompleted == 'NO':
                    print("no")
                    if totalhouralloted <= (previoushourworked + currenthourworked):
                        print("hours due")
                        task.TaskStatus = TaskStatus.objects.get(TaskStatusID=4)
                        task.TaskHourWorked = previoushourworked + currenthourworked
                        task.save()
                    else:
                        task.TaskHourWorked = previoushourworked + currenthourworked
                        task.save()
            taskassigned = Task.objects.filter(TaskEmpID__UserID=request.session['UserID'])
            taskstatus = ['OVERDUE','NOT STARTED','IN PROGRESS','COMPLETE']
            return render(request, "memberhome.html", {'tasks': taskassigned, 'taskstatus': taskstatus})
        else:
            form = ReportTaskForm(initial={'TaskName':task.TaskName,'TaskTotalHours':task.TaskTotalHours,'TaskHourWorked':task.TaskHourWorked})
        return render(request, "reporttaskmodal.html", {'editform': form, 'taskid': taskid})

def memberteam(request):
    if memberlogin_required(request.session['logged_in'], request.session['Role']):
        assignedprojectid= AssignedProject.objects.get(UserID= request.session['UserID']).ProjectID
        managerid= User.objects.get(UserID=request.session['UserID']).ManagerID_id
        manager= User.objects.get(UserID= managerid)
        membersid= AssignedProject.objects.filter(ProjectID = assignedprojectid).values_list('UserID',flat=True)
        members= User.objects.filter(UserID__in=membersid).exclude(UserID=request.session['UserID'])
        teams = members.values_list('TeamID__TeamName', flat=True).distinct()
        return render(request,"memberteam.html",{'manager':manager,'members':members,'teams':teams,'navbar':'1'})

def chatwithuser(request, userid=None):
    if request.session['logged_in']:
        loggedinuser = User.objects.get(UserID=request.session['UserID'])
        chatwithuser = User.objects.get(UserID=userid)
        c = ChatMessenger.objects.filter(MessageSentFrom__in=[loggedinuser,chatwithuser],MessageSentTo__in=[loggedinuser,chatwithuser]).order_by('Created')
        return render(request, "chatpage.html", {'Chat': c, 'chatwithuser': chatwithuser, 'user': request.session['UserID']})

def post(request):
    if request.method == "POST":
        msg = request.POST.get('msgbox', None)
        userid = request.POST.get('chatwithuser', None)
        loggedinuser = User.objects.get(UserID=request.session['UserID'])
        chatwithuser = User.objects.get(UserID=userid)
        c = ChatMessenger(MessageSentFrom=loggedinuser, MessageSentTo=chatwithuser, Message=msg)
        if msg != '':
            c.save()
        return JsonResponse({'msg': msg, 'user': request.session['UserID']})
    else:
        return HttpResponse('Request must be POST.')

def messages(request, userid=None):
    if request.session['logged_in']:
        loggedinuser = User.objects.get(UserID=request.session['UserID'])
        chatwithuser = User.objects.get(UserID=userid)
        c = ChatMessenger.objects.filter(MessageSentFrom__in=[loggedinuser,chatwithuser],MessageSentTo__in=[loggedinuser,chatwithuser]).order_by('Created')
        return render(request, "message.html", {'Chat': c, 'user': request.session['UserID']})

def calender(request):
    user= User.objects.get(UserID=request.session['UserID'])
    role = request.session['Role']
    if role == '1':
       base_template=  "adminnavbar.html"
    elif role == '2':
        base_template = 'managernavbar.html'
    elif role == '3':
        base_template= 'membernavbar.html'
    return render(request, "calender.html", {'user':user, 'sidebar':3, 'Role':role, "base_template": base_template})

def addevent(request):
    if request.method == "POST":
        summary = request.POST['summary']
        address = request.POST['address']
        description = request.POST['description']
        startdate = request.POST['startdate']
        starttime = request.POST['starttime']
        enddate = request.POST['enddate']
        endtime = request.POST['endtime']
        start = startdate+'T'+starttime+':00'
        end = enddate+'T'+endtime+':00'
        acha = google(summary, address, description, start, end)
        acha.insertevent()
        print('insert ho geya')
        user = User.objects.get(UserID=request.session['UserID'])
        role = request.session['Role']
        if role == '1':
            base_template = "adminnavbar.html"
        elif role == '2':
            base_template = 'managernavbar.html'
        elif role == '3':
            base_template = 'membernavbar.html'
        return render(request, "calender.html", {'user': user, 'sidebar': 3,"base_template":base_template})
    else:
        return render(request, "addeventmodal.html")


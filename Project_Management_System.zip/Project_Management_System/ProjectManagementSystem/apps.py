from django.apps import AppConfig


class ProjectmanagementsystemConfig(AppConfig):
    name = 'ProjectManagementSystem'

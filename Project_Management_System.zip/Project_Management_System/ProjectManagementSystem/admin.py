from django.contrib import admin
from .models import User, Project, Notes, SubTask,TaskPriority,Milestones,MilestoneStatus,TaskStatus,Task,ProjectStatus,Client,AssignedProject,Roles,Teams, ChatMessenger

admin.site.register(User)
admin.site.register(Project)
admin.site.register(SubTask)
admin.site.register(TaskPriority)
admin.site.register(Milestones)
admin.site.register(MilestoneStatus)
admin.site.register(TaskStatus)
admin.site.register(Task)
admin.site.register(ProjectStatus)
admin.site.register(Client)
admin.site.register(AssignedProject)
admin.site.register(Teams)
admin.site.register(Roles)
admin.site.register(Notes)
admin.site.register(ChatMessenger)


